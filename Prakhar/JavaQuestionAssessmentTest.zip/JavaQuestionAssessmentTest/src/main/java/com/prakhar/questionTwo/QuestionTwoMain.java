package com.prakhar.questionTwo;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class QuestionTwoMain {
    public static void main(String[] args){
        try {
            System.out.println("How many elements you want to add in a List");
            Scanner sc = new Scanner(System.in);
            int num = sc.nextInt();

            int tempNum;
            List<Integer> list = new ArrayList<>();
            for (int i = 0; i < num; i++) {
                System.out.print("Input the " + i + " element of the list: ");
                tempNum = sc.nextInt();
                list.add(tempNum);
            }

            int sum = 0, min = list.get(0), max = list.get(0);
            //finding the sum and average
            for (int elem : list) {
                sum += elem;

                //for getting maximum
                if (elem > max) {
                    max = elem;
                }

                //for getting min
                if (elem < min) {
                    min = elem;
                }
            }
            System.out.println("\nSum of the list element :" + sum + "\nAverage of the list : " + (sum / num));


            //Maximum and minimum value in the list
            System.out.println("\nMax of the list element :" + max + "\nMin of the list : " + min);


//            List<Integer> newList = list.;

//            System.out.println(newList);
        }catch (Exception e){
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
