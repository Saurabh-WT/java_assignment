package com.prakhar.questionOne;

public class BankAccount {
    String fullName;
    Double amount;
    String accountType;

    public BankAccount(String fullName, Double amount, String accountType) {
        this.fullName = fullName;
        this.amount = amount;
        this.accountType = accountType;
        System.out.println("Your Account is created with details:\n Name : "+fullName+"\n Balance : "+amount+"\n Account Type: "+ accountType);
    }

    public BankAccount() {
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }


    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void withdrawAmount(double drawAmount){
        if(drawAmount>amount){
            System.out.println("You don't have enough balance");
        }
        amount -= drawAmount;
        System.out.println("Amount remaining after withdrawing: "+amount );
    }
    public void deposit(double depositAmount){
        amount -= depositAmount;
        System.out.println("Amount after deposit: "+amount );
    }
    public void balanceEnquery(){
        System.out.println("Current Remaining Balance : "+amount );
    }
}
