package com.prakhar.questionOne;

public class QuestionOneMain {
    public static void main(String[] args){
        try {
            System.out.println();
            BankAccount bankAccount = new BankAccount("Prakhar", 1000.0, "Savings");

            System.out.println("\nChecking Balance:");
            //Checking Amount balance
            bankAccount.balanceEnquery();

            System.out.println("\nDepositing Money:");
            //depositing Money
            bankAccount.deposit(100.0);

            System.out.println("\nWithdrawing Money:");
            //Withdrawing Money
            bankAccount.withdrawAmount(500.0);
            System.out.println();

            System.out.println("\nChecking Balance again:");
            //Checking Amount balance again
            bankAccount.balanceEnquery();
        }catch (Exception e){
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}
