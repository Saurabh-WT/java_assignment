package com.prakhar.questionFive;

import java.util.Scanner;

public class QuestionFiveMain {
    public static void main(String[] args){
        try {
            Calculator addition = (a, b) -> (double) (a + b);
            Calculator substraction = (a, b) -> (double) (a - b);
            Calculator multiplication = (a, b) -> (double) (a * b);
            Calculator division = (a, b) -> (double) (a) / (double) (b);
            Scanner sc= new Scanner(System.in);
            int choice=0,num1,num2;

            while (choice != 5) {
                System.out.println("Choose your choice \n 1 for add,\n 2 for subtract, \n 3 for multiply, \n 4 for division and\n 5 for exit.\nEnter your choice:");
                choice = sc.nextInt();

                switch (choice){
                    case 1:
                        System.out.println("Enter 2 number for operation:\n");
                        num1=sc.nextInt();
                        num2=sc.nextInt();
                        System.out.println("Result: "+addition.operation(num1,num2));
                        break;
                    case 2:
                        System.out.println("Enter 2 number for operation:\n");
                        num1=sc.nextInt();
                        num2=sc.nextInt();
                        System.out.println("Result: "+substraction.operation(num1,num2));
                        break;
                    case 3:
                        System.out.println("Enter 2 number for operation:\n");
                        num1=sc.nextInt();
                        num2=sc.nextInt();
                        System.out.println("Result: "+multiplication.operation(num1,num2));
                        break;
                    case 4:
                        System.out.println("Enter 2 number for operation:\n");
                        num1=sc.nextInt();
                        num2=sc.nextInt();
                        System.out.println("Result: "+division.operation(num1,num2));
                        break;
                    case 5:
                        System.exit(1);
                        break;
                    default:
                        System.out.println("Invalid choice");
                }
            }
        }catch (Exception e){
            System.err.println(e.getMessage());
            e.printStackTrace();
        }
    }
}

@FunctionalInterface
interface Calculator{
    Double operation(int a , int b);
}