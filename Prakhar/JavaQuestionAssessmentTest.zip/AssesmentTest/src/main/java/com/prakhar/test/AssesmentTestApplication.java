package com.prakhar.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssesmentTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssesmentTestApplication.class, args);
    }

}
