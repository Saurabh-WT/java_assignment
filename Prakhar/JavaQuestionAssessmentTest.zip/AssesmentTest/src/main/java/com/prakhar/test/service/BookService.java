package com.prakhar.test.service;

import com.prakhar.test.model.Book;
import com.prakhar.test.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BookService {

    private static BookRepository bookRepository;

    public  ResponseEntity getAllBooks() {
        List<Book> books= bookRepository.findAll();
        if(books.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(books);
    }

    public ResponseEntity getBookById(int id){
        Optional<Book> book = bookRepository.findById(id);
        if(book.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(book);
    }

    public ResponseEntity addBook(Book book){
        if(book.getBookName()==null && book.getAuthorName()==null && book.getPublisherName()==null){
            return ResponseEntity.badRequest().body("Book Name, Author name and publisher name is Required");
        }

        try {
            Book createdBook = bookRepository.save(book);
            return ResponseEntity.ok(createdBook);

        }catch (Exception e){
            //we can log here too in place of System.err.println()
            System.err.println("Error creating a book : "+e.getMessage());
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }

    public ResponseEntity updateBook(int id,Book updatedBook){
        Optional<Book> book= bookRepository.findById(id);
        if(book.isEmpty()){
            Book existingBook= book.get();
            if(updatedBook.getBookName()!=null){
                existingBook.setBookName(updatedBook.getBookName());
            }
            if(updatedBook.getPublisherName()!=null){
                existingBook.setPublisherName(updatedBook.getPublisherName());
            }
            if(updatedBook.getAuthorName()!=null){
                existingBook.setAuthorName(updatedBook.getAuthorName());
            }
            try {
                Book responseBook =bookRepository.save(existingBook);
                return ResponseEntity.ok(responseBook);
            }catch (Exception e){
                //we can log here too in place of System.err.println()
                System.err.println("Error updating a book : "+e.getMessage());
                e.printStackTrace();
                return ResponseEntity.internalServerError().build();
            }
        }else {
            return ResponseEntity.notFound().build();
        }

    }


    public ResponseEntity deleteBook(int id) {
        Optional<Book> book = bookRepository.findById(id);
        if(book.isPresent()){
            try {
                bookRepository.deleteById(id);
                return ResponseEntity.noContent().build();
            }catch (Exception e){
                //we can log here too in place of System.err.println()
                System.err.println("Error deleting a book : "+e.getMessage());
                e.printStackTrace();
                return ResponseEntity.internalServerError().build();
            }
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
