package com.prakhar.test.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    @Id
    int id;

    @Column(name = "book_name")
    String bookName;

    @Column(name="author_name")
    String authorName;

    @Column(name="publisher")
    String publisherName;


}
