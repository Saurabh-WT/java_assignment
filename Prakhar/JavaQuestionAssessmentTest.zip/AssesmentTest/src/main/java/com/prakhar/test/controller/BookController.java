package com.prakhar.test.controller;

import com.prakhar.test.model.Book;
import com.prakhar.test.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/book")
@RequiredArgsConstructor
public class BookController {

    private static BookService bookService;

    @GetMapping
    public ResponseEntity getAllBooks(){
        return bookService.getAllBooks();
    }

    @PostMapping
    public ResponseEntity addBook(@RequestBody Book book){
        return bookService.addBook(book);
    }

    @GetMapping("/{id}")
    public ResponseEntity getBookById(@PathVariable(name = "id") int id){
        return bookService.getBookById(id);
    }


    @PostMapping("/update/{id}")
    public ResponseEntity updateBook(@PathVariable(name = "id") int id,Book updatedBook){
        return bookService.updateBook(id,updatedBook);
    }

    @PostMapping("/delete/{id}")
    public ResponseEntity deleteBook(@PathVariable("id") int id){
        return bookService.deleteBook(id);
    }

}
